keepinventory_backup = keepinventory_backup or {}

minetest.register_on_dieplayer(function(player)
    if not player then return end
    local player_name = player:get_player_name()
    local inv = player:get_inventory()

    -- Backup inventory
    keepinventory_backup[player_name] = {}
    local lists = inv:get_lists()
    for list_name, items in pairs(lists) do
        keepinventory_backup[player_name][list_name] = {}
        for i = 1, #items do
            keepinventory_backup[player_name][list_name][i] = items[i]:to_string()
        end
    end

    -- Clear inventory to prevent item drops on death
    for list_name, _ in pairs(lists) do
        inv:set_list(list_name, {})
    end
end)

minetest.register_on_respawnplayer(function(player)
    local player_name = player:get_player_name()
    local inv = player:get_inventory()

    if keepinventory_backup[player_name] then
        for list_name, items in pairs(keepinventory_backup[player_name]) do
            for i, item_string in pairs(items) do
                inv:set_stack(list_name, i, ItemStack(item_string))
            end
        end
        keepinventory_backup[player_name] = nil
    end
end)
